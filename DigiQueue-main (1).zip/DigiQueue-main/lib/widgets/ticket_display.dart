import 'dart:async';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Large animated token number display widget.
/// Changes color and animations based on queue position.
class TicketDisplay extends StatefulWidget {
  final int tokenNumber;
  final int currentServing;
  final int peopleAhead;
  final bool isYourTurn;

  /// True when the professor has started calling students (currentServing > 0)
  final bool queueStarted;

  /// Non-null when it is THIS student's turn and the professor put a hold.
  /// A countdown timer will be shown to the student.
  final DateTime? holdUntil;

  const TicketDisplay({
    super.key,
    required this.tokenNumber,
    required this.currentServing,
    required this.peopleAhead,
    required this.isYourTurn,
    this.queueStarted = true,
    this.holdUntil,
  });

  @override
  State<TicketDisplay> createState() => _TicketDisplayState();
}

class _TicketDisplayState extends State<TicketDisplay>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _numberController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _scaleAnimation;

  int _displayedServing = 0;

  // Hold countdown
  Timer? _holdTimer;
  Duration _holdRemaining = Duration.zero;

  @override
  void initState() {
    super.initState();
    _displayedServing = widget.currentServing;

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _numberController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _numberController, curve: Curves.elasticOut),
    );

    if (_isYourTurn) {
      _pulseController.repeat(reverse: true);
    }
    _numberController.forward();
    _startHoldTimer();
  }

  @override
  void didUpdateWidget(TicketDisplay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentServing != widget.currentServing) {
      _numberController.reset();
      _numberController.forward();
      setState(() => _displayedServing = widget.currentServing);
    }
    if (_isYourTurn && !_pulseController.isAnimating) {
      _pulseController.repeat(reverse: true);
    } else if (!_isYourTurn && _pulseController.isAnimating) {
      _pulseController.stop();
      _pulseController.reset();
    }
    if (oldWidget.holdUntil != widget.holdUntil) {
      _holdTimer?.cancel();
      _startHoldTimer();
    }
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _pulseController.dispose();
    _numberController.dispose();
    super.dispose();
  }

  void _startHoldTimer() {
    if (widget.holdUntil == null) {
      setState(() => _holdRemaining = Duration.zero);
      return;
    }
    _updateHoldRemaining();
    _holdTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _updateHoldRemaining();
    });
  }

  void _updateHoldRemaining() {
    final remaining = widget.holdUntil!.difference(DateTime.now());
    setState(() {
      _holdRemaining = remaining.isNegative ? Duration.zero : remaining;
    });
  }

  String get _holdCountdown {
    final m = _holdRemaining.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = _holdRemaining.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  bool get _isYourTurn => widget.isYourTurn;

  // Only trigger "almost your turn" when the queue has actually started AND
  // there are 2 or fewer people left ahead (not when queue is idle at 0)
  bool get _isAlmostTurn =>
      widget.queueStarted && widget.peopleAhead <= 2 && !_isYourTurn;

  Color get _statusColor {
    if (widget.holdUntil != null) return AppColors.warning;
    if (_isYourTurn) return AppColors.success;
    if (_isAlmostTurn) return AppColors.warning;
    return AppColors.primary;
  }

  Color get _glowColor {
    if (widget.holdUntil != null) return AppColors.warningGlow;
    if (_isYourTurn) return AppColors.successGlow;
    if (_isAlmostTurn) return AppColors.warningGlow;
    return AppColors.surfaceHighlight;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ── Hold Banner (professor put the queue on hold) ──
        if (widget.holdUntil != null)
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: child,
              );
            },
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: AppColors.warning.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: AppColors.warning.withValues(alpha: 0.35),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.pause_circle_rounded,
                      color: AppColors.warning, size: 22),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Queue on hold',
                        style: TextStyle(
                          color: AppColors.warning,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        _holdRemaining > Duration.zero
                            ? 'Resuming in $_holdCountdown'
                            : 'Resuming shortly…',
                        style: TextStyle(
                          color: AppColors.warning.withValues(alpha: 0.8),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

        // ── "It's Your Turn!" Banner (only when not on hold) ──
        if (_isYourTurn && widget.holdUntil == null)
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: child,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                gradient: AppColors.successGradient,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.success.withValues(alpha: 0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.celebration_rounded, color: Colors.white, size: 22),
                  SizedBox(width: 10),
                  Text(
                    "It's Your Turn!",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),

        // ── Your Token Number ──
        Text(
          'YOUR TOKEN',
          style: TextStyle(
            color: AppColors.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 8),
        AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            final scale = _isYourTurn ? _pulseAnimation.value : 1.0;
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _statusColor,
                  _statusColor.withValues(alpha: 0.7),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: _statusColor.withValues(alpha: 0.4),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Center(
              child: Text(
                '${widget.tokenNumber}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 48,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 32),

        // ── Currently Serving ──
        Text(
          widget.queueStarted ? 'CURRENTLY SERVING' : 'QUEUE STATUS',
          style: const TextStyle(
            color: AppColors.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 8),
        ScaleTransition(
          scale: _scaleAnimation,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            decoration: GlassDecoration.elevated(glowColor: _statusColor),
            child: Text(
              widget.queueStarted ? '#$_displayedServing' : 'Waiting to start',
              style: TextStyle(
                color: widget.queueStarted
                    ? _statusColor
                    : AppColors.textSecondary,
                fontSize: widget.queueStarted ? 36 : 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),

        // ── People Ahead / Status ──
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            color: _glowColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _statusColor.withValues(alpha: 0.2),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _isYourTurn && widget.holdUntil == null
                    ? Icons.arrow_forward_rounded
                    : !widget.queueStarted
                        ? Icons.hourglass_top_rounded
                        : widget.holdUntil != null
                            ? Icons.pause_rounded
                            : Icons.people_outline_rounded,
                color: _statusColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                _isYourTurn && widget.holdUntil == null
                    ? 'Head to the office now!'
                    : widget.holdUntil != null
                        ? 'Your turn — professor will be back'
                        : !widget.queueStarted
                            ? widget.peopleAhead == 0
                                ? "You're first — queue starting soon"
                                : '${widget.peopleAhead} ${widget.peopleAhead == 1 ? 'person' : 'people'} ahead'
                            : '${widget.peopleAhead} ${widget.peopleAhead == 1 ? 'person' : 'people'} ahead',
                style: TextStyle(
                  color: _statusColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
